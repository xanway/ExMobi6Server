package com.fh.demo.controller.path;
/**
 * 此类适配公司Path系统
 * 类中两方法实现了服务与业务系统会话维持效果
 */

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Node;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fiberhome.business.paramconfig.ParamConfig;
import com.fiberhome.common.suport.xpath.CachedDom4jXpathProcessImpl;
import com.fiberhome.common.suport.xpath.IXPathProcess;
import com.fiberhome.common.util.XmlUtil;
import com.fiberhome.http.bean.FormParamter;
import com.fiberhome.http.bean.HttpContext;
import com.fiberhome.http.bean.HttpHeader;
import com.fiberhome.http.bean.HttpRequestBean;
import com.fiberhome.http.bean.HttpResponseBean;
import com.fiberhome.http.impl.HttpUtilWithOutEncode;
import com.fiberhome.spring.annotate.api.ApiDescription;
import com.fiberhome.spring.annotate.api.ApiFailResponseBody;
import com.fiberhome.spring.annotate.api.ApiRequestBody;
import com.fiberhome.spring.annotate.api.ApiSuccessResponseBody;

@Controller
@RequestMapping(value="/doauth/path")
public class PathHttpController {

	private static final Logger logger = Logger.getLogger(PathHttpController.class);
	
	/**
	 * Path系统登录
	 * @param request 
	 * @param session
	 * @param username 用户名
	 * @param password 密码
	 * @return Json数据
	 * @throws Exception
	 */
	@RequestMapping(value="/dologin")
	@ResponseBody
	@ApiRequestBody(exampleValue="username=abc&password=456")
	@ApiSuccessResponseBody(exampleFile="doLoginSucBody.json")
	@ApiFailResponseBody(exampleFile="doLoginFailBody.json")
	@ApiDescription("提交登录")
	public Object dologin(HttpServletRequest request,final HttpSession session,@RequestParam(required=true,value="username") String username,@RequestParam(required=true,value="password") String password)throws Exception{
		//初始构建上下文
		final HttpContext httpContext = new HttpContext();
		httpContext.setContextId(session.getId());
		// 后续请求均采用带有上下文的方式构建HttpUtil请求第三方业务系统
		//url中有特殊符号，HttpUtilWithOutEncode可使请求时不对url进行编码
		HttpUtilWithOutEncode httpUtil = new HttpUtilWithOutEncode(httpContext);
		HttpRequestBean req = new HttpRequestBean();
		//设置url
		String url = "http://"+ParamConfig.getValue("pathdomain")+"/path/SSO!login.action";
		req.setUrl(url);
		req.setEnctype(1);
		//设置请求头
		List<HttpHeader> headers = new ArrayList<HttpHeader>();
		headers.add(new HttpHeader("Content-Type", "application/x-www-form-urlencoded"));
		req.setHeaders(headers);
		//设置Method
		req.setMethod("POST");
		//设置请求参数
		List<FormParamter> params = new ArrayList<FormParamter>();
		params.add(new FormParamter("gourl", ""));
		params.add(new FormParamter("loginname", username));
		params.add(new FormParamter("password", password));
		req.setFormParams(params);
		
		//发起请求
		HttpResponseBean rsp = httpUtil.sendHttpRequest(req);
		// 获取响应吗
		int status = rsp.getStatusCode();
		//html转Dom文件
		Document dom = XmlUtil.html2xml(rsp.getResponseBody("UTF-8"));
		IXPathProcess ixp = new CachedDom4jXpathProcessImpl();
		Node sucNode = (Node)ixp.selectNode("//a[@id='my_task_list']", dom);
		JSONObject rspJson = new JSONObject();
		if(null != sucNode && status == 200){
			//将当前上下文存储到会话中
			session.setAttribute("httpContext", httpContext);
			rspJson.put("result", "success");
		}else{
			rspJson.put("result", "fail");
			rspJson.put("msg", "用户名或密码错误");
		}
		return rspJson;
	}
	
	/**
	 * 待办任务信息
	 * @param session
	 * @return 待办任务json数据
	 * @throws Exception
	 */
	@RequestMapping(value="/tasklist")
	@ResponseBody
	@ApiSuccessResponseBody(exampleFile="taskListSucBody.json")
	@ApiFailResponseBody(exampleFile="taskListFailBody.json")
	@ApiDescription("获取待办任务信息")
	public Object getTaskList(HttpSession session) throws Exception{
		//从当前会话中获取上下文
		HttpContext httpContext = (HttpContext)session.getAttribute("httpContext");
		//url中有特殊符号，HttpUtilWithOutEncode可使请求时不对url进行编码
		HttpUtilWithOutEncode httpUtil = new HttpUtilWithOutEncode(httpContext);
		HttpResponseBean rsp =httpUtil.sendGet("http://"+ParamConfig.getValue("pathdomain")+"/path/projecttask/TaskAction!filerTaskItems.action?search-isovertime=&search-starttime=&search-endtime=&search-content=mytask&search-projectid=&search-type=&search-status=1070101%2C1070102%2C1070103&search-priority=&search-isdelay=&pageIndex=1&pageSize=10&sortField=priority&sortOrder=");
		String data = rsp.getResponseBody("utf-8");
		JSONObject rspJson = new JSONObject();
		// 获取响应吗
		int status = rsp.getStatusCode();
		if(status == 200){
			rspJson = JSON.parseObject(data);
		}else{
			rspJson.put("result", "fail");
			rspJson.put("msg","业务系统响应异常，请联系管理员");
		}
		return rspJson;
	}
}
