package com.fh.demo.controller.push;

/**
 * 此类为推送消息实现类
 * 数据库操作未采用Mybatis，采用exmobi-jar自带DB操作类
 */

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.fh.demo.controller.db.DbController;
import com.fiberhome.access.registerdevice.RegisterDevice;
import com.fiberhome.db.bean.TableRow;
import com.fiberhome.db.impl.DBProcessImpl;
import com.fiberhome.interfaces.ms.server.registerdevice.beans.DeviceInfo;
import com.fiberhome.push.PnsPushManager;
import com.fiberhome.push.bean.GetPushStatusRequest;
import com.fiberhome.push.bean.GetPushStatusResponse;
import com.fiberhome.push.bean.PushMessageRequest;
import com.fiberhome.push.bean.PushMessageResponse;

@Controller
@RequestMapping(value="/doauth/push")
public class PushController {

	private static final Logger logger= LoggerFactory.getLogger(DbController.class);
	
	@Resource(name="dataSource2")
	private DataSource ds;
	
	/**
	 * 设备信息采集方法
	 * @param request
	 * @param username 用户名
	 * @return Json数据
	 * @throws Exception
	 */
	@RequestMapping(value="/pushlogin")
	@ResponseBody
	public Object pushLogin(HttpServletRequest request,@RequestParam(required=true,value="username") String username)throws Exception{
		
		// 从请求头中获取设备信息
		RegisterDevice registerDevice = new RegisterDevice();
		DeviceInfo info = registerDevice.getDeviceInfo(request);
		DBProcessImpl aaa= new DBProcessImpl(ds);
		String querySql = "select * from tbl_user where username = ? and esn = ? and clientid = ?";
		List<TableRow> rows = aaa.queryRows(querySql, new Object[]{username,info.getEsn(),info.getClientId()});
		int insertResult = 0;
		if(!(rows.size() > 0)){
			String insertSql = "insert into tbl_user (uuid,esn,clientid,username) values (?,?,?,?)";
			insertResult = aaa.update(insertSql, new Object[]{UUID.randomUUID().toString(),info.getEsn(),info.getClientId(),username});
		}
		
		JSONObject rspJson = new JSONObject();
		if(rows.size()>0 || insertResult >0){
			rspJson.put("result", "success");
		}else{
			rspJson.put("result", "fail");
		}
		return rspJson;
	}
	
	/**
	 * 触发推送方法
	 * @param username 业务系统登录帐号
	 * @param title	   消息标题
	 * @param content 消息内容
	 * @return Json数据
	 * @throws Exception
	 */
	@RequestMapping(value="/sendPush")
	@ResponseBody
	public Object sendPush(@RequestParam(required=true,value="username")String username,@RequestParam(required=true,value="title")String title,@RequestParam(required=true,value="content")String content)
			throws Exception{
		DBProcessImpl aaa= new DBProcessImpl(ds);
		String querySql = "select * from tbl_user where username = ?";
		List<TableRow> rows = aaa.queryRows(querySql, new Object[]{username});
		PushMessageRequest pushRequestBean = new PushMessageRequest();
		PnsPushManager pnsPushManager = new PnsPushManager();
		pnsPushManager.setPnsServiceUrl("http://192.168.160.167:8001/services/pnsService");
		List<String> destAddr = new ArrayList<String>();
		for(TableRow row :rows){
			destAddr.add("esn:"+row.getField("esn", ""));
		}
		pushRequestBean.setApplicationId("gaeaclient-android-edn16807");
		pushRequestBean.setCheckkey("bcs");
		pushRequestBean.setDestAddr(destAddr);
		pushRequestBean.setMsgContent("{\"titlehead\": \"ExMobi\",\"title\": \""+content+"\",\"app\": \"newpush\",\"page\": \"page/push.uixml\"}");
		pushRequestBean.setTitle(title);
		pushRequestBean.setType("app");
		
		String toServerResult = "";
		String toClientResult = "";
		try
		{
			PushMessageResponse pushMessageResponse = pnsPushManager.pushMessage(pushRequestBean);
			if(null!=pushMessageResponse){
				toServerResult = pushMessageResponse.getResult() + "=======" + pushMessageResponse.getMsg();
				logger.info(pushMessageResponse.getResult() + "=======" + pushMessageResponse.getMsg());
//				System.out.println(pushMessageResponse.getResult() + "=======" + pushMessageResponse.getMsg());
			}
			try {
				Thread.sleep(2000);
				GetPushStatusRequest getPushStatusRequestBean = new GetPushStatusRequest();
				// 设置推送标识
				getPushStatusRequestBean.setRequestIdentifier(pushMessageResponse.getRequestIdentifier());
				// 获取推送结果
				GetPushStatusResponse getPushStatusResponseBean = pnsPushManager.getPushStatus(getPushStatusRequestBean);
				toClientResult = getPushStatusResponseBean.getDeliveryStatusList().toString();
				logger.info("获取推送结果响应：" + getPushStatusResponseBean.getDeliveryStatusList().toString());
//				System.out.println("获取推送结果响应：" + getPushStatusResponseBean.getDeliveryStatusList().toString());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}catch (Exception e){
			e.printStackTrace();
		}
		JSONObject json = new JSONObject();
		json.put("result", "success");
		json.put("toServerResult", toServerResult);
		json.put("toClientResult", toClientResult);
		return json;
	}
}
