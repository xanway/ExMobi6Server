package com.fh.demo.controller.preview;

/**
 * 此类为预览功能示例
 */

import java.io.InputStream;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.fiberhome.business.paramconfig.ParamConfig;
import com.fiberhome.http.bean.HttpResponseBean;
import com.fiberhome.http.impl.HttpUtil;
import com.fiberhome.preview.FileToImage;
import com.fiberhome.preview.bean.DocConvertParam;
import com.fiberhome.preview.bean.FilePreviewResult;

@Controller
@RequestMapping(value="/preview")
public class PreviewController {

	@RequestMapping(value="/doPreview")
	@ResponseBody
	public Object doPreview(Model model,@RequestParam(required=false,value="pageNum")String pageNum)throws Exception{
		String dcsAddress = ParamConfig.getValue("dcsserver");
		FileToImage fileToImage = new FileToImage(dcsAddress);
		FilePreviewResult result = null;
		DocConvertParam docConvertParam = new DocConvertParam();
		if(null!=pageNum){
			docConvertParam.setPageNum(Integer.parseInt(pageNum));
		}else{
			docConvertParam.setPageNum(1);
		}
		docConvertParam.setSrcFileExt("doc");
		HttpUtil httpUtil = new HttpUtil();
		String url ="http://www.exmobi.cn/resource/download/info/c53183b0-9483-11e3-a740-d55aa0e0e58f.do";
		HttpResponseBean rsp = httpUtil.sendGet(url);
		InputStream is = rsp.getResponseFileInputStream();
		result=fileToImage.convertToJpg(is, docConvertParam);
		String convertResult = result.getResult();//获取转换结果
		String convertMsg = result.getMsg();//获取转换结果描述信息
		String convertIdentifier = result.getConvertIdentifier();//获取文档转换唯一标识
		String fileMd5 = result.getFileMd5();//获取源文档md5值
		int totalPageNum = result.getTotalPageNum();//获取文档总页数
		int currentPageNum = result.getCurrentPageNum();//获取当前预览页数
		String imgBase64Str = fileToImage.getPageBase64(result);
		JSONObject rspJson = new JSONObject();
		rspJson.put("convertMsg", convertMsg);
		rspJson.put("convertIdentifier", convertIdentifier);
		rspJson.put("fileMd5", fileMd5);
		rspJson.put("totalPageNum", totalPageNum);
		rspJson.put("currentPageNum", currentPageNum);
		rspJson.put("imgBase64Str", imgBase64Str);
		return rspJson;
	}
}
