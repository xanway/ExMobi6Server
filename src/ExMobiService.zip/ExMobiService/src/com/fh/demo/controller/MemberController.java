package com.fh.demo.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fh.demo.entity.Member;
import com.fh.demo.service.IMemberService;

@Controller
@RequestMapping("/demo")
public class MemberController {

	@Resource
	private IMemberService memberService;
	
	@RequestMapping("/showMember")
	public String showMember(Model model,@RequestParam(required=false,value="memberId")String memberId)throws Exception{
		Member member = this.memberService.getMemberById(memberId);
		model.addAttribute("member", member);
		return "showmember";
	}
}
