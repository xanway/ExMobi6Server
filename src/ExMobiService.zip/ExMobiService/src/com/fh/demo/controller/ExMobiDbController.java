package com.fh.demo.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fh.demo.entity.Member;
import com.fiberhome.db.bean.TableRow;
import com.fiberhome.db.impl.DBProcessImpl;

@Controller
@RequestMapping("/exmobidb")
public class ExMobiDbController {

	private static final Logger logger= LoggerFactory.getLogger(ExMobiDbController.class);
	
	//采用注解方式引入spring-db.xml配置的数据源bean对象
	@Resource(name="dataSource")
	private DataSource ds;
	
	//返回jsp视图处理
	@RequestMapping("/page")
	public String getMembers(Model model,@RequestParam(required=false,value="memberName")String memberName) throws Exception{
		logger.info("============查询部门信息==========");
		DBProcessImpl aaa = new DBProcessImpl(ds);
		if(null != memberName && memberName.length()>0){
			model.addAttribute("customers", aaa .queryRows("SELECT * FROM tbl_member WHERE name LIKE ?", new Object[] {"%"+memberName+"%"}));
		}else{
			
			model.addAttribute("customers", aaa .queryRows("SELECT * FROM tbl_member LIMIT 10 OFFSET 0", null));
		}
		return "customer";
	}
	
	//返回json数据
	@RequestMapping("/json")
	@ResponseBody
	public Object getMembers(@RequestParam(required=false,value="memberName")String memberName) throws Exception{
		logger.info("============查询部门信息==========");
		DBProcessImpl aaa = new DBProcessImpl(ds);
		List<TableRow> members = new ArrayList<TableRow>();
		if(null != memberName && memberName.length()>0){
			members = aaa .queryRows("SELECT * FROM tbl_member WHERE name LIKE ?", new Object[] {"%"+memberName+"%"});
		}else{
			members = aaa .queryRows("SELECT * FROM tbl_member LIMIT 10 OFFSET 0", new Object[] {null});
		}
		return members;
	}
}

