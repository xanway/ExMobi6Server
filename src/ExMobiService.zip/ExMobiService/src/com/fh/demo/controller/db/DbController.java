package com.fh.demo.controller.db;

/**
 * 此类为数据库适配示例类
 * 数据库操作采用Mybatis
 */

import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fh.demo.entity.Member;
import com.fh.demo.service.IMemberService;
import com.fiberhome.db.impl.DBProcessImpl;

@Controller
@RequestMapping(value="/db",method=RequestMethod.GET)
public class DbController {

	private static final Logger logger= LoggerFactory.getLogger(DbController.class);
	
	@Resource(name="dataSource")
	private DataSource ds;
	
	@Resource(name="memberService")
	private IMemberService memberService;
	
	/**
	 * 查询客户信息
	 * @param model
	 * @param name 成员名字
	 * @return 页面视图
	 * @throws Exception
	 */
	@RequestMapping(value="/page")
	public String getCustomer(Model model,@RequestParam(required=false,value="name")String name) throws Exception{
		logger.info("查询客户信息");
		List<Member> members = this.memberService.getMembers(name);
		model.addAttribute("customers",members);
		return "customer";
	}
	
	
	/**
	 * 查询客户信息
	 * @param name 成员名字
	 * @return json结构
	 * @throws Exception
	 */
	@RequestMapping(value="/json")
	@ResponseBody
	public Object getCustomer(@RequestParam(required=false,value="name")String name) 
			throws Exception{
		logger.info("查询客户信息");
		
		List<Member> members = this.memberService.getMembers(name);
		return members;
	}
}
