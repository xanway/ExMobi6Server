package com.fh.demo.controller;

/**
 * 此类为页面抓取示例
 */

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Node;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fiberhome.common.suport.xpath.CachedDom4jXpathProcessImpl;
import com.fiberhome.common.suport.xpath.IXPathProcess;
import com.fiberhome.common.util.XmlUtil;
import com.fiberhome.http.bean.HttpResponseBean;
import com.fiberhome.http.impl.HttpUtil;

@Controller
@RequestMapping(value="/WebParse")
public class WebParseController {

	private static final Logger logger = Logger.getLogger(WebParseController.class);
	
	@RequestMapping("/edu/xpath")
	@ResponseBody
	public Object getEduList() throws Exception{
		HttpUtil httpUtil = new HttpUtil();
		String url = "https://edu.exmobi.cn/";
		HttpResponseBean rsp = httpUtil.sendGet(url);//发起http请求
		JSONObject rspJson = new JSONObject();
		JSONArray articlesArray = new JSONArray();
		// 获取响应吗
		int status = rsp.getStatusCode();
		if(status == 200){
			//html转Dom文件
			Document dom = XmlUtil.html2xml(rsp.getResponseBody("UTF-8"));
			IXPathProcess ixp = new CachedDom4jXpathProcessImpl();
			List<Object> articles = ixp.selectNodes("//div[@class='col-xs-6 col-md-3 edit']", dom);
			for(Object at:articles){
				Node atNode = (Node)at;
				JSONObject article = new JSONObject();
				article.put("title", ixp.selectNodeValue("./a/div/h6[1]/text()", atNode));
				article.put("content", ixp.selectNodeValue("./a/div/h6[2]/text()", atNode));
				article.put("href", ixp.selectNodeValue("./a/@href", atNode));
				article.put("img", ixp.selectNodeValue("./a/img/@src", atNode));
				articlesArray.add(article);
			}
			rspJson.put("articles", articlesArray);
		}else{
			rspJson.put("result", "fail");
			rspJson.put("msg","业务系统响应异常，请联系管理员");
		}
		return rspJson;
	}
	
	@RequestMapping("/edu/regex")
	@ResponseBody
	public Object getEduListByRegex() throws Exception{
		HttpUtil httpUtil = new HttpUtil();
		String url = "https://edu.exmobi.cn/";
		HttpResponseBean rsp = httpUtil.sendGet(url);//发起http请求
		JSONObject rspJson = new JSONObject();
		JSONArray articlesArray = new JSONArray();
		if(rsp.getStatusCode() == 200){
			rspJson.put("result", "success");
			//替换网页源字符串中所有换行、制表、回车、报警符以方便正则替换
			String rspStr = rsp.getResponseBody("UTF-8").replaceAll("\\r|\\t|\\n|\\a", "");
			String regex = "<div class=\"col-xs-6 col-md-3 edit\">\\s*<a class=\"thumbnail\" href=\"([^\"]+)\">\\s*<img style=\"width: 100%;height: 240px;\" data-src=\"([^\"]+)\" src=\"([^\"]+)\" alt=\"...\" >\\s*<div class=\"caption\">\\s*<h6>([^<]+)</h6>\\s*<h6 class=\"subhead\">([^<]+)</h6>\\s*<div>\\s*<span class=\"glyphicon glyphicon-user subhead-content\"></span>\\s* <span class=\"subhead-content\">([^<]+)</span>\\s*<span style=\"float:right;color:#bbb;font-size:12px;margin-top:3px;\">([^<]+)</span>\\s*</div>\\s*</div>\\s*</a>\\s*</div>";
			Pattern p = Pattern.compile(regex);
			Matcher matcher = p.matcher(rspStr.replaceAll("\\r|\\t|\\n|\\a", ""));
			while(matcher.find()){
				JSONObject article = new JSONObject();
				article.put("title", matcher.group(4).trim());
				article.put("content", matcher.group(5).trim());
				article.put("href", matcher.group(1).trim());
				article.put("img", matcher.group(3).trim());
				articlesArray.add(article);
			}
			rspJson.put("articles", articlesArray);
		}else{
			rspJson.put("result", "fail");
			rspJson.put("msg","业务系统响应异常，请联系管理员");
		}
		return rspJson;
	}
}
