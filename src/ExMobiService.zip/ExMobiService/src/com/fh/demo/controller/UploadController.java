package com.fh.demo.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

@Controller
@RequestMapping("/upload")
public class UploadController {

	@RequestMapping("/goupload")
	public String goUploadPage(Model model){
		return "fileUpload";
	}
	
	/**
	 * 附件上传
	 * @param model
	 * @param file
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/doupload", method = RequestMethod.POST)
	public String fileUpload(Model model,@RequestParam(required=true,value="file") CommonsMultipartFile file,HttpServletRequest request) throws Exception{
		// 获取文件类型  
        System.out.println(file.getContentType());  
        // 获取文件大小  
        System.out.println(file.getSize());  
        // 获取文件名称  
        System.out.println(file.getOriginalFilename());  
        // 判断文件是否存在  
        if (!file.isEmpty()) {  
        	// 文件保存路径  
//            String path = request.getSession().getServletContext().getRealPath("/") + "upload/"  
//                    + file.getOriginalFilename();  
            String path = "D:/file/temp/" + file.getOriginalFilename();  
            File localFile = new File(path);  
            try {  
                file.transferTo(localFile);  
            } catch (IllegalStateException e) {  
                e.printStackTrace();  
            } catch (IOException e) {  
                e.printStackTrace();  
            }  
        }  
        return "redirect:/upload/list";
	}
	
	 /*** 
     * 读取上传文件中得所有文件并返回 
     *  
     * @return 
     */  
    @RequestMapping("/list")  
    @ResponseBody
    public Object list(HttpServletRequest request) {  
//        String filePath = request.getSession().getServletContext().getRealPath("/") + "upload/";  
        String filePath = "D:/file/temp";  
        File uploadDest = new File(filePath);  
        String[] fileNames = uploadDest.list();  
        
        for (int i = 0; i < fileNames.length; i++) {  
            //打印出文件名  
            System.out.println(fileNames[i]);  
        }  
        return fileNames;  
    }  
}
