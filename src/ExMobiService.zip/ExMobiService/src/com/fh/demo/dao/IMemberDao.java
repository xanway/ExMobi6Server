package com.fh.demo.dao;

import java.util.List;

import com.fh.demo.entity.Member;

public interface IMemberDao {
    int deleteByPrimaryKey(String memberId);

    int insert(Member record);

    int insertSelective(Member record);

    Member selectByPrimaryKey(String memberId);
    
    List<Member> selectAll();
    
    List<Member> selectByName(String memberName);

    int updateByPrimaryKeySelective(Member record);

    int updateByPrimaryKey(Member record);
}