package com.fh.demo.service;

import java.util.List;

import com.fh.demo.entity.Member;

public interface IMemberService {

	public Member getMemberById(String memberId);
	
	public List<Member> getMembers(String memberName);
}
