package com.fh.demo.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.fh.demo.dao.IMemberDao;
import com.fh.demo.entity.Member;
import com.fh.demo.service.IMemberService;

@Service("memberService")
public class MemberServiceImpl implements IMemberService{

	@Resource
	private IMemberDao memberDao;
	
	@Override
	public Member getMemberById(String memberId) {
		// TODO Auto-generated method stub
		return this.memberDao.selectByPrimaryKey(memberId);
	}

	@Override
	public List<Member> getMembers(String memberName) {
		// TODO Auto-generated method stub
		if(null!=memberName && !"null".equals(memberName) && memberName.length()>0){
			return this.memberDao.selectByName("%"+memberName+"%");
		}else{
			return this.memberDao.selectAll();
		}
	}

}
